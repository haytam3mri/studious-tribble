PHANTOM / PowerUp site skeleton patch

Change made:
- Fixed /admin route: the archive contains control-panel-xyz987.html in the project root, but server.js was looking for a missing public/admin.html.

Run on Android (Termux with Node.js installed):
1. Extract this ZIP.
2. Open Termux in the PowerUp-main folder.
3. Run: node server.js
4. Open http://127.0.0.1:3000/ for the main page.
5. Open http://127.0.0.1:3000/admin for the control panel.

Important:
- This only fixes the site UI route; it does not activate or create official Phantom licenses.
- Do not expose this server to the public internet as-is. The source has a default admin password and questionable license-validation behavior.
- This package is not verified as an official Phantom project.
